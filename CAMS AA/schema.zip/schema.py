from pymongo import MongoClient

client=pymongo.MongoClient('mongodb://localhost:27017/')

db = client['test']


schema_validators_for_employees_bank = {
   "$jsonSchema" : {
               "bsonType": "object",
               "required": ["ver","timestamp","txnid","clienttxnid","purpose","Notifier","type","id","consentId","consentHandle","Status"],
               "properties": {
                  "ver": {
                     "bsonType": "int",
                  },
                  "timestamp": {
                     "bsonType": "string",
                     "minimum": "10",
                     "maximum": "50",
                     "description": "must be a string and is required"
                  },
                  "txnid": {
                     "bsonType": "string",
                     "description": "must be a string"
                  },
                  "clienttxnid": {
                     "bsonType": "string",
                     "description": "must be a string and it is optional "
                  },
                  "purpose":{
                     "bsonType": "string",
                     "description": "must be a string",
                  },
                  "Notifier": {
                     "description": "Optional",
                  },
                  "type": {
                     "bsonType": "string",
                     "description": "must be a string and   is required",
                  },
                  "id": {
                     "bsonType": "string",
                     "description": "must be a string and   is required",
                  },
                  "consentId": {
                     "bsonType": "int",
                     "description": "must be a int and   is required",
                  },
                  "consentHandle": {
                     "bsonType": "string",
                     "description": "must be a string and   is required",
                  },
                  "Status": {
                     "bsonType": "string",
                     "description": "must be a string and   is required",
                  },
               }
               
            }
}

try:
   # db.create_collection("admin",validator=schema_validators)
   db.create_collection("admin2")
   db.create_collection("employeeDetails",validator= schema_validators_for_employees_bank)
except Exception as e:
   print(e)


# db.command("callMod",validator=schema_validators)
adminCol = db["admin2"]
# adminCol = db["employeeDetails"]
employeeCol = db["employeeDetails"]


